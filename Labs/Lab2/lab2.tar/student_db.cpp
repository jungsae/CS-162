#include "student_db.h"

student *create_student_db(int n)
{
    student *students_db = new student[n];
    return students_db;
};

void get_student_db_info(student *student_db, int n, std::fstream &fin)
{
    for (int i = 0; i < n; i++)
    {
        fin >> student_db[i].idNumber;
        fin >> student_db[i].firstName;
        fin >> student_db[i].lastName;
        fin >> student_db[i].major;
    }
}

void delete_student_db_info(student *studnet_db)
{
    delete[] studnet_db;
    studnet_db = NULL;
}

void sort_by_id(student *student_db, int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (student_db[j].idNumber > student_db[j + 1].idNumber)
            {
                student temp = student_db[j];
                student_db[j] = student_db[j + 1];
                student_db[j + 1] = temp;
            }
        }
    }
    for (int i = 0; i < n; i++)
    {
        cout << student_db[i].idNumber << " " << student_db[i].firstName << " " << student_db[i].lastName << " " << student_db[i].major << " " << endl;
    }
    cout << endl;
}

void sort_by_lastName(student *student_db, int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (student_db[j].lastName > student_db[j + 1].lastName)
            {
                student temp = student_db[j];
                student_db[j] = student_db[j + 1];
                student_db[j + 1] = temp;
            }
        }
    }
    for (int i = 0; i < n; i++)
    {
        cout << student_db[i].idNumber << " " << student_db[i].firstName << " " << student_db[i].lastName << " " << student_db[i].major << " " << endl;
    }
    cout << endl;
}