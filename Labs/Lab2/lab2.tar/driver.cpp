#include "student_db.h"

int main(int argc, char* argv[])
{
    if (argc != 2)
    {
        cerr << " Error " << endl;
        return 1;
    }
    fstream ipfile(argv[1], ios::in);
    if (ipfile.fail())
    {
        cerr << "Failed to open file: " << argv[1] << endl;
        return 1;
    }
    int numOfStudent;
    ipfile >> numOfStudent;
    student* students = create_student_db(numOfStudent);
    get_student_db_info(students,numOfStudent,ipfile);
    int exitNumber;
    do
    {
        int choice = 0;
        cout << "Choose what you want to do: "<< endl;
        cout << "Sort By ID (Press 1)" << endl;
        cout << "Sort By LastNumber (Press 2)" << endl;
        cout << "Exit (Press 3)" << endl;
        cin >> choice;
        if (choice == 1)
        {
            sort_by_id(students,numOfStudent);    
        }
        else if(choice == 2)
        {
            sort_by_lastName(students,numOfStudent);
        }
        else if(choice == 3)
        {
            exitNumber = choice;
        }
    } while (exitNumber != 3);
    ipfile.close();
    delete_student_db_info(students);
    return 0;
}