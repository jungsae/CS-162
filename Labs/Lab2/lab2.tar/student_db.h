#ifndef STUDENT_DB_H
#define STUDENT_DB_H

#include <iostream>
#include <fstream>
#include <string> 
using namespace std;

struct student
{
   int idNumber;
   string firstName;
   string lastName;
   string major;
};

student* create_student_db(int); 
void get_student_db_info(student*, int, std::fstream&); 
void sort_by_id(student*, int);
void sort_by_lastName(student*, int);
void delete_student_db_info(student *);

#endif